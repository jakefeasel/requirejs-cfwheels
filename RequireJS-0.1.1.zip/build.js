({
    appDir: "../../javascripts",
    baseUrl: ".",
    dir: "../../javascripts_min",
    modules: [
        {
            name: "main"
        }
    ]
})